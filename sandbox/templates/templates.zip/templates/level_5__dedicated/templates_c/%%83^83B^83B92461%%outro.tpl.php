<?php /* Smarty version 2.6.18, created on 2008-02-15 18:47:25
         compiled from page/home/outro.tpl */ ?>
Goodbye from <u>Home</u>