<?php require_once(dirname(__FILE__).'/_header.php'); ?>

		<div class="search">
		
			<div class="search_intro">
			Welcome to Search
			</div>
		
			<div class="search_content">
			
				<div class="search_result">
					<div class="search_result_title">
					Welcome to Search Result One
					</div>
					<div class="search_result_content">
					Search Result One Contents
					</div>
					<div class="search_result_outro">
					Goodbye from Search Result One
					</div>
				</div>
			
				<div class="search_result">
					<div class="search_result_title">
					Welcome to Search Result Two
					</div>
					<div class="search_result_content">
					Search Result Two Contents
					</div>
					<div class="search_result_outro">
					Goodbye from Search Result Two
					</div>
				</div>
			
				<div class="search_result">
					<div class="search_result_title">
					Welcome to Search Result Three
					</div>
					<div class="search_result_content">
					Search Result Three Contents
					</div>
					<div class="search_result_outro">
					Goodbye from Search Result Three
					</div>
				</div>
				
			</div>
			
			<div class="search_outro">
			Goodbye from Search
			</div>
		
		</div>

<?php require_once(dirname(__FILE__).'/_footer.php'); ?>