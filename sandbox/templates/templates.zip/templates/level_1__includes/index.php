<?php require_once(dirname(__FILE__).'/_header.php'); ?>

		<div class="home">
			<div class="home_intro">
			Welcome to Home
			</div>
			<div class="home_content">
			Home Contents
			</div>
			<div class="home_outro">
			Goodbye from Home
			</div>
		</div>
		
<?php require_once(dirname(__FILE__).'/_footer.php'); ?>