
	</div>
	
	<div class="container_outro">
	Goodbye from Container
	</div>
	
</div>

<div class="links">
<a href="index.php">Home</a>
<a href="search.php">Search</a>
</div>

</body>
</html>